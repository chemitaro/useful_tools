# テストが機能しているかどうかを確認するためのテスト
def test_add():
    assert 1 + 1 == 2
